package editor;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.EventQueue;
import java.awt.Graphics;

import javax.swing.*;


public class Board extends JPanel implements ActionListener {
	private Timer timer;
	Tile tile;
	Boolean running = true;
	private final int DELAY = 15;
	Board(){ 
		setBounds(0,80,200,200);    
	    setBackground(Color.gray);    
        boardInit();
        repaint();


        
	}
	
	public void boardInit(){
		tile = new Tile(0,80,"src/res/sphere.png");
		timer = new Timer(DELAY, this);
        timer.start();
	}
	
	

	
	
	
	@Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(tile.getImage(), tile.getX(), tile.getY(), this);
        
        
        
	}
	
	@Override
    public void actionPerformed(ActionEvent e) {
        repaint();
        tile.x +=1;
    }
	
	

    private class TAdapter extends KeyAdapter {

        @Override
        public void keyReleased(KeyEvent e) {
           // player.keyReleased(e);
        }

        @Override
        public void keyPressed(KeyEvent e) {
           // player.keyPressed(e);
        }
    }



	
	
	
	
	
	
}
