package editor;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;

import javax.swing.*;


public class Board extends JPanel {

	Tile tile;
	Board(){ 
		setBounds(0,80,200,200);    
	    setBackground(Color.gray);    
        boardInit();
        repaint();


        
	}
	
	public void boardInit(){
		tile = new Tile(0,80,"src/res/sphere.png");
		
	}
	
	
	
	@Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(tile.getImage(), tile.getX(), tile.getY(), this);
       
        
        
	}
	
	
	
}
