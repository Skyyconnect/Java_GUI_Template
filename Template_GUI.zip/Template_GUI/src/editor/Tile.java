package editor;

public class Tile extends Sprite {
	public String imgPath;
	Tile(int x, int y, String imgPath){
		super(x,y);
		this.imgPath = imgPath;
		init();
	}
	
	private void init() {
		loadImage(this.imgPath);
		getImageDimensions();
	}
}
