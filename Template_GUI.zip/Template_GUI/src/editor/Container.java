package editor;

import java.awt.EventQueue;
import javax.swing.JFrame;

public class Container extends JFrame {

    public Container() {
        
        initUI();
    }
    
    private void initUI() {
        
        add(new Board());
        setSize(400,400);
        setResizable(true);
        //pack();
        
        setTitle("Editor");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                Container ex = new Container();
                ex.setVisible(true);
                
            }
        });
    }
}